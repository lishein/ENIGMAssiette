package com.example.enigmassiette;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();


        Button btnSave = findViewById(R.id.buttonSave);
        btnSave.setOnClickListener(v -> {
            String restaurantName = ((EditText) findViewById(R.id.editTextRestaurantName)).getText().toString();
            String date = ((EditText) findViewById(R.id.editTextDate)).getText().toString();
            String time = ((EditText) findViewById(R.id.editTextTime)).getText().toString();
            float decorationRating = ((RatingBar) findViewById(R.id.rb_decoration)).getRating();
            float foodRating = ((RatingBar) findViewById(R.id.rb_food)).getRating();
            float serviceRating = ((RatingBar) findViewById(R.id.rb_service)).getRating();
            String review = ((EditText) findViewById(R.id.editTextDescription)).getText().toString();

            addReview(restaurantName, date, time, decorationRating, foodRating, serviceRating, review);
            Toast.makeText(MainActivity.this, "Review added!", Toast.LENGTH_SHORT).show();

        });

        ListView reviewsListView = findViewById(R.id.reviewsListView);
        ArrayList<String> reviews = getReviews();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, reviews);
        reviewsListView.setAdapter(adapter);
    }

    public void addReview(String restaurantName, String date, String time, float decorationRating, float foodRating, float serviceRating, String review) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_RESTAURANT_NAME, restaurantName);
        values.put(DatabaseHelper.COLUMN_DATE, date);
        values.put(DatabaseHelper.COLUMN_TIME, time);
        values.put(DatabaseHelper.COLUMN_DECORATION_RATING, decorationRating);
        values.put(DatabaseHelper.COLUMN_FOOD_RATING, foodRating);
        values.put(DatabaseHelper.COLUMN_SERVICE_RATING, serviceRating);
        values.put(DatabaseHelper.COLUMN_REVIEW, review);

        database.insert(DatabaseHelper.TABLE_NAME, null, values);
    }

    @Override
    protected void onDestroy() {
        database.close();
        dbHelper.close();
        super.onDestroy();
    }

    private ArrayList<String> getReviews() {
        ArrayList<String> reviews = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String restaurantName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_RESTAURANT_NAME));
            String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE));
            String time = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TIME));
            String review = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_REVIEW));

            String displayText = restaurantName + "\nDate: " + date + " Time: " + time + "\nReview: " + review;
            reviews.add(displayText);
        }
        cursor.close();
        return reviews;
    }
}


