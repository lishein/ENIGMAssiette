package com.example.enigmassiette;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Nom de la base de données
    private static final String DATABASE_NAME = "restaurant_reviews.db";

    // Version de la base de données, à changer si vous modifiez la structure
    private static final int DATABASE_VERSION = 1;

    // Nom de la table et noms des colonnes
    public static final String TABLE_NAME = "reviews";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_RESTAURANT_NAME = "restaurant_name";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_DECORATION_RATING = "decoration_rating";
    public static final String COLUMN_FOOD_RATING = "food_rating";
    public static final String COLUMN_SERVICE_RATING = "service_rating";
    public static final String COLUMN_REVIEW = "review";

    // Commande SQL pour créer la table
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_RESTAURANT_NAME + " TEXT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_TIME + " TEXT, " +
                    COLUMN_DECORATION_RATING + " FLOAT, " +
                    COLUMN_FOOD_RATING + " FLOAT, " +
                    COLUMN_SERVICE_RATING + " FLOAT, " +
                    COLUMN_REVIEW + " TEXT" + ");";

    // Constructeur
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Création de la table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    // Mise à jour de la base de données si nécessaire
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void deleteReview(int reviewId) {
        // Obtenez une instance de la base de données pour écrire
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(DatabaseHelper.TABLE_NAME, DatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(reviewId)});

        // Fermer la base de données après l'opération
        db.close();
    }
}
